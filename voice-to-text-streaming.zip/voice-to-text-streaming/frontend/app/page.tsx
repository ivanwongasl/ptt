"use client";

import { useEffect, useMemo, useRef, useState } from "react";

const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

type Segment = {
  start: number;
  end: number;
  text: string;
};

const languageOptions = [
  { value: "", label: "Auto detect" },
  { value: "en", label: "English" },
  { value: "zh", label: "Chinese" },
  { value: "ja", label: "Japanese" },
  { value: "ko", label: "Korean" },
  { value: "es", label: "Spanish" },
  { value: "fr", label: "French" },
  { value: "de", label: "German" },
  { value: "ms", label: "Malay" },
  { value: "id", label: "Indonesian" },
];

function formatTime(totalSeconds: number) {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function formatSegmentTime(seconds: number) {
  return `${seconds.toFixed(2)}s`;
}

export default function HomePage() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [recordedMimeType, setRecordedMimeType] = useState("audio/webm");
  const [transcript, setTranscript] = useState("");
  const [segments, setSegments] = useState<Segment[]>([]);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const [language, setLanguage] = useState("");
  const [detectedLanguage, setDetectedLanguage] = useState("");
  const [languageProbability, setLanguageProbability] = useState<number | null>(
    null,
  );
  const [duration, setDuration] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [waveform, setWaveform] = useState<number[]>(Array(24).fill(10));

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<BlobPart[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const waveformRef = useRef<NodeJS.Timeout | null>(null);

  const audioPreviewUrl = useMemo(() => {
    if (!recordedBlob) return "";
    return URL.createObjectURL(recordedBlob);
  }, [recordedBlob]);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (waveformRef.current) clearInterval(waveformRef.current);
      if (audioPreviewUrl) URL.revokeObjectURL(audioPreviewUrl);
    };
  }, [audioPreviewUrl]);

  const resetMessages = () => {
    setStatus("");
    setError("");
  };

  const resetTranscript = () => {
    setTranscript("");
    setSegments([]);
    setDetectedLanguage("");
    setLanguageProbability(null);
    setDuration(null);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    resetMessages();
    resetTranscript();

    const file = event.target.files?.[0] || null;
    setSelectedFile(file);
    setRecordedBlob(null);
  };

  const startFakeWaveform = () => {
    waveformRef.current = setInterval(() => {
      setWaveform((prev) =>
        prev.map(() =>
          Math.max(8, Math.min(54, Math.floor(Math.random() * 54))),
        ),
      );
    }, 120);
  };

  const stopFakeWaveform = () => {
    if (waveformRef.current) clearInterval(waveformRef.current);
    setWaveform(Array(24).fill(10));
  };

  const startTimer = () => {
    timerRef.current = setInterval(() => {
      setRecordSeconds((prev) => prev + 1);
    }, 1000);
  };

  const stopTimer = () => {
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const startRecording = async () => {
    resetMessages();
    resetTranscript();
    console.log("Requesting microphone...");

    if (!navigator.mediaDevices?.getUserMedia) {
      setError("Your browser does not support microphone recording.");
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      console.log("Microphone granted");

      const mimeType = MediaRecorder.isTypeSupported("audio/webm")
        ? "audio/webm"
        : "audio/mp4";

      const recorder = new MediaRecorder(stream, { mimeType });
      mediaRecorderRef.current = recorder;
      recordedChunksRef.current = [];
      setRecordedMimeType(mimeType);
      setRecordSeconds(0);

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: mimeType });
        setRecordedBlob(blob);
        setSelectedFile(null);
        stream.getTracks().forEach((track) => track.stop());
      };

      recorder.start();
      setIsRecording(true);
      setStatus("Recording started...");
      startTimer();
      startFakeWaveform();
    } catch {
      setError("Microphone permission denied or recording failed.");
    }
  };

  const stopRecording = () => {
    if (!mediaRecorderRef.current) return;
    mediaRecorderRef.current.stop();
    setIsRecording(false);
    setStatus("Recording stopped. Ready to transcribe.");
    stopTimer();
    stopFakeWaveform();
  };

  const handleTranscribe = async () => {
    resetMessages();
    resetTranscript();

    if (!selectedFile && !recordedBlob) {
      setError("Please upload an audio file or record audio first.");
      return;
    }

    try {
      setIsSubmitting(true);
      setStatus("Uploading and transcribing audio...");

      const formData = new FormData();

      if (selectedFile) {
        formData.append("file", selectedFile);
      } else if (recordedBlob) {
        const extension = recordedMimeType.includes("mp4") ? "m4a" : "webm";
        const file = new File([recordedBlob], `recording.${extension}`, {
          type: recordedMimeType,
        });
        formData.append("file", file);
      }

      if (language) {
        formData.append("language", language);
      }

      const response = await fetch(`${API_BASE_URL}/transcribe`, {
        method: "POST",
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || "Transcription failed.");
      }

      setTranscript(data.text || "");
      setSegments(data.segments || []);
      setDetectedLanguage(data.language || "");
      setLanguageProbability(
        typeof data.language_probability === "number"
          ? data.language_probability
          : null,
      );
      setDuration(typeof data.duration === "number" ? data.duration : null);
      setStatus("Transcription completed successfully.");
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Something went wrong.";
      setError(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setSelectedFile(null);
    setRecordedBlob(null);
    setRecordSeconds(0);
    resetMessages();
    resetTranscript();
    stopTimer();
    stopFakeWaveform();
    setIsRecording(false);
  };

  const copyTranscript = async () => {
    if (!transcript) return;
    try {
      await navigator.clipboard.writeText(transcript);
      setStatus("Transcript copied to clipboard.");
      setError("");
    } catch {
      setError("Failed to copy transcript.");
    }
  };

  return (
    <main className="page">
      <div className="container">
        <div className="hero">
          <h1>Voice to Text</h1>
          <p>
            Upload an audio file or record your voice directly in the browser,
            then transcribe it with FastAPI and faster-whisper.
          </p>
        </div>

        <div className="grid">
          <section className="card">
            <h2>Audio Input</h2>
            <p>Select a file or record a new voice message.</p>

            <div className="section">
              <label className="label" htmlFor="audio-upload">
                Upload audio file
              </label>
              <input
                id="audio-upload"
                className="fileInput"
                type="file"
                accept="audio/*"
                onChange={handleFileChange}
              />
              {selectedFile && (
                <div className="fileName">
                  Selected file: {selectedFile.name}
                </div>
              )}
            </div>

            <div className="section">
              <label className="label" htmlFor="language-select">
                Transcription language
              </label>
              <select
                id="language-select"
                className="select"
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
              >
                {languageOptions.map((option) => (
                  <option key={option.value || "auto"} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <div className="smallText" style={{ marginTop: 8 }}>
                Choose a language or leave it on auto detect.
              </div>
            </div>

            <div className="section">
              <label className="label">Record audio</label>

              <div className="buttonRow">
                {!isRecording ? (
                  <button
                    className="button primary"
                    onClick={startRecording}
                    disabled={isSubmitting}
                  >
                    Start Recording
                  </button>
                ) : (
                  <button className="button danger" onClick={stopRecording}>
                    Stop Recording
                  </button>
                )}

                <button
                  className="button success"
                  onClick={handleTranscribe}
                  disabled={isSubmitting || isRecording}
                >
                  {isSubmitting ? "Transcribing..." : "Transcribe"}
                </button>

                <button
                  className="button secondary"
                  onClick={handleReset}
                  disabled={isSubmitting}
                >
                  Reset
                </button>
              </div>

              <div className="audioBox">
                <div className="recordMeta">
                  <div>
                    <div className="smallText">Record timer</div>
                    <div className="timer">{formatTime(recordSeconds)}</div>
                  </div>

                  <div className="smallText">
                    {isRecording ? "Recording live..." : "Not recording"}
                  </div>
                </div>

                <div className="waveform" aria-hidden="true">
                  {waveform.map((height, index) => (
                    <div
                      key={index}
                      className="bar"
                      style={{ height: `${height}px` }}
                    />
                  ))}
                </div>

                {recordedBlob && (
                  <audio
                    className="audioPreview"
                    controls
                    src={audioPreviewUrl}
                  />
                )}
              </div>
            </div>

            {status && (
              <div className={`status ${error ? "statusError" : "statusInfo"}`}>
                {status}
              </div>
            )}

            {error && <div className="status statusError">{error}</div>}
          </section>

          <section className="card">
            <h2>Transcript Result</h2>

            <div className="metaGrid">
              <div className="metaItem">
                <span className="metaItemTitle">Detected language</span>
                <div className="metaItemValue">{detectedLanguage || "—"}</div>
              </div>

              <div className="metaItem">
                <span className="metaItemTitle">Language confidence</span>
                <div className="metaItemValue">
                  {languageProbability !== null
                    ? `${(languageProbability * 100).toFixed(1)}%`
                    : "—"}
                </div>
              </div>

              <div className="metaItem">
                <span className="metaItemTitle">Duration</span>
                <div className="metaItemValue">
                  {duration !== null ? `${duration.toFixed(2)}s` : "—"}
                </div>
              </div>

              <div className="metaItem">
                <span className="metaItemTitle">Requested language</span>
                <div className="metaItemValue">{language || "Auto detect"}</div>
              </div>
            </div>

            <div
              className="buttonRow"
              style={{ marginTop: 0, marginBottom: 16 }}
            >
              <button
                className="button secondary"
                onClick={copyTranscript}
                disabled={!transcript}
              >
                Copy Transcript
              </button>
            </div>

            <div className="resultBox">
              {transcript || (
                <span className="emptyState">
                  Your transcribed text will appear here.
                </span>
              )}
            </div>

            {segments.length > 0 && (
              <div className="segmentList">
                {segments.map((segment, index) => (
                  <div
                    key={`${segment.start}-${segment.end}-${index}`}
                    className="segmentItem"
                  >
                    <div className="segmentTime">
                      {formatSegmentTime(segment.start)} -{" "}
                      {formatSegmentTime(segment.end)}
                    </div>
                    <div>{segment.text}</div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </main>
  );
}
