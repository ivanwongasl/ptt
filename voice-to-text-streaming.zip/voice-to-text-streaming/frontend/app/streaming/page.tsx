"use client";

import { useEffect, useMemo, useRef, useState } from "react";

const WS_BASE_URL =
  (process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000")
    .replace("http://", "ws://")
    .replace("https://", "wss://");

type Metrics = {
  chunk_count: number;
  bytes_received: number;
  samples_received: number;
  seconds_received: number;
  sample_rate: number;
  channels: number;
  encoding: string;
  language: string;
  committed_count: number;
  buffer_samples: number;
};

type ServerMessage =
  | { type: "status"; message: string }
  | { type: "partial"; text: string }
  | { type: "committed"; texts: string[] }
  | { type: "done"; text: string }
  | { type: "metrics"; data: Metrics }
  | { type: "error"; message: string };

const languageOptions = [
  { value: "auto", label: "Auto detect" },
  { value: "en", label: "English" },
  { value: "zh", label: "Chinese" },
  { value: "ja", label: "Japanese" },
  { value: "ko", label: "Korean" },
  { value: "es", label: "Spanish" },
  { value: "fr", label: "French" },
  { value: "de", label: "German" },
  { value: "ms", label: "Malay" },
  { value: "id", label: "Indonesian" },
];

function formatTime(totalSeconds: number) {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function downsampleBuffer(
  buffer: Float32Array,
  inputSampleRate: number,
  outputSampleRate: number
): Float32Array {
  if (outputSampleRate === inputSampleRate) {
    return buffer;
  }

  if (outputSampleRate > inputSampleRate) {
    throw new Error("Output sample rate must be less than or equal to input sample rate.");
  }

  const sampleRateRatio = inputSampleRate / outputSampleRate;
  const newLength = Math.round(buffer.length / sampleRateRatio);
  const result = new Float32Array(newLength);

  let offsetResult = 0;
  let offsetBuffer = 0;

  while (offsetResult < result.length) {
    const nextOffsetBuffer = Math.round((offsetResult + 1) * sampleRateRatio);
    let accum = 0;
    let count = 0;

    for (let i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i++) {
      accum += buffer[i];
      count++;
    }

    result[offsetResult] = count > 0 ? accum / count : 0;
    offsetResult++;
    offsetBuffer = nextOffsetBuffer;
  }

  return result;
}

function floatTo16BitPCM(float32Array: Float32Array): ArrayBuffer {
  const buffer = new ArrayBuffer(float32Array.length * 2);
  const view = new DataView(buffer);

  let offset = 0;
  for (let i = 0; i < float32Array.length; i++, offset += 2) {
    let sample = Math.max(-1, Math.min(1, float32Array[i]));
    sample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
    view.setInt16(offset, sample, true);
  }

  return buffer;
}

export default function StreamingPage() {
  const [isRecording, setIsRecording] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState("disconnected");
  const [statusMessage, setStatusMessage] = useState("Idle");
  const [partialText, setPartialText] = useState("");
  const [finalText, setFinalText] = useState("");
  const [doneText, setDoneText] = useState("");
  const [language, setLanguage] = useState("auto");
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [error, setError] = useState("");
  const [waveform, setWaveform] = useState<number[]>(Array(24).fill(10));
  const [metrics, setMetrics] = useState<Metrics | null>(null);

  const socketRef = useRef<WebSocket | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const sourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const processorNodeRef = useRef<ScriptProcessorNode | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const streamingTranscript = useMemo(() => {
    return [finalText, partialText, doneText].filter(Boolean).join(" ").trim();
  }, [finalText, partialText, doneText]);

  useEffect(() => {
    return () => {
      void cleanup();
    };
  }, []);

  const startTimer = () => {
    timerRef.current = setInterval(() => {
      setRecordSeconds((prev) => prev + 1);
    }, 1000);
  };

  const stopTimer = () => {
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const updateWaveform = (samples: Float32Array) => {
    const bars = 24;
    const bucketSize = Math.max(1, Math.floor(samples.length / bars));
    const nextBars: number[] = [];

    for (let i = 0; i < bars; i++) {
      const start = i * bucketSize;
      const end = Math.min(start + bucketSize, samples.length);
      let peak = 0;

      for (let j = start; j < end; j++) {
        peak = Math.max(peak, Math.abs(samples[j]));
      }

      nextBars.push(Math.max(8, Math.min(54, Math.round(peak * 54))));
    }

    setWaveform(nextBars);
  };

  const cleanup = async () => {
    stopTimer();

    if (processorNodeRef.current) {
      processorNodeRef.current.disconnect();
      processorNodeRef.current.onaudioprocess = null;
      processorNodeRef.current = null;
    }

    if (sourceNodeRef.current) {
      sourceNodeRef.current.disconnect();
      sourceNodeRef.current = null;
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }

    if (audioContextRef.current) {
      await audioContextRef.current.close();
      audioContextRef.current = null;
    }

    if (socketRef.current) {
      if (socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }
      socketRef.current = null;
    }

    setWaveform(Array(24).fill(10));
    setIsRecording(false);
    setConnectionStatus("disconnected");
  };

  const connectWebSocket = () => {
    return new Promise<WebSocket>((resolve, reject) => {
      const ws = new WebSocket(`${WS_BASE_URL}/ws/transcribe`);
      ws.binaryType = "arraybuffer";

      let settled = false;

      ws.onopen = () => {
        socketRef.current = ws;
        setConnectionStatus("connected");
        setStatusMessage("Connected to streaming server.");

        ws.send(
          JSON.stringify({
            type: "config",
            language,
            sample_rate: 16000,
            encoding: "pcm_s16le",
            channels: 1,
          })
        );

        settled = true;
        resolve(ws);
      };

      ws.onerror = () => {
        if (!settled) {
          settled = true;
          reject(new Error("WebSocket connection failed."));
        }
        setError("WebSocket error.");
      };

      ws.onclose = () => {
        setConnectionStatus("disconnected");
        setStatusMessage("Disconnected.");
      };

      ws.onmessage = (event) => {
        try {
          const data: ServerMessage = JSON.parse(event.data);

          if (data.type === "status") {
            setStatusMessage(data.message);
          } else if (data.type === "partial") {
            setPartialText(data.text);
          } else if (data.type === "committed") {
            setFinalText((prev) => `${prev} ${data.texts.join(" ")}`.trim());
            setPartialText("");
          } else if (data.type === "done") {
            setDoneText(data.text);
            setPartialText("");
          } else if (data.type === "metrics") {
            setMetrics(data.data);
          } else if (data.type === "error") {
            setError(data.message);
          }
        } catch {
          setError("Failed to parse server message.");
        }
      };
    });
  };

  const startRecording = async () => {
    setError("");
    setPartialText("");
    setFinalText("");
    setDoneText("");
    setMetrics(null);
    setRecordSeconds(0);

    try {
      console.log("Requesting microphone...");

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      console.log("Microphone granted");
      mediaStreamRef.current = stream;

      const audioContext = new AudioContext();
      audioContextRef.current = audioContext;
      console.log("AudioContext sample rate:", audioContext.sampleRate);

      const sourceNode = audioContext.createMediaStreamSource(stream);
      sourceNodeRef.current = sourceNode;

      const processorNode = audioContext.createScriptProcessor(4096, 1, 1);
      processorNodeRef.current = processorNode;

      const ws = await connectWebSocket();

      processorNode.onaudioprocess = (event) => {
        if (ws.readyState !== WebSocket.OPEN) return;

        const inputData = event.inputBuffer.getChannelData(0);
        const floatCopy = new Float32Array(inputData);
        updateWaveform(floatCopy);

        const downsampled = downsampleBuffer(
          floatCopy,
          audioContext.sampleRate,
          16000
        );

        const pcmBuffer = floatTo16BitPCM(downsampled);
        console.log("Sending PCM chunk:", pcmBuffer.byteLength);
        ws.send(pcmBuffer);
      };

      sourceNode.connect(processorNode);
      processorNode.connect(audioContext.destination);

      setIsRecording(true);
      setStatusMessage("Streaming raw PCM audio...");
      startTimer();
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Failed to start streaming.";
      console.error("Start streaming failed:", message);
      setError(message);
      await cleanup();
    }
  };

  const stopRecording = async () => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type: "stop" }));
    }

    setStatusMessage("Stopping stream...");
    await cleanup();
  };

  const copyTranscript = async () => {
    if (!streamingTranscript) return;

    try {
      await navigator.clipboard.writeText(streamingTranscript);
      setStatusMessage("Transcript copied to clipboard.");
      setError("");
    } catch {
      setError("Failed to copy transcript.");
    }
  };

  return (
    <main className="page">
      <div className="container">
        <div className="hero">
          <h1>Live Streaming Transcription</h1>
          <p>
            Stream raw PCM microphone audio to the backend. This page is prepared
            for real <strong>ufal/SimulStreaming</strong> integration.
          </p>
        </div>

        <div className="grid">
          <section className="card">
            <h2>Streaming Controls</h2>

            <div className="section">
              <label className="label" htmlFor="stream-language">
                Streaming language
              </label>
              <select
                id="stream-language"
                className="select"
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                disabled={isRecording}
              >
                {languageOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="section">
              <div className="buttonRow">
                {!isRecording ? (
                  <button className="button primary" onClick={startRecording}>
                    Start Streaming
                  </button>
                ) : (
                  <button className="button danger" onClick={stopRecording}>
                    Stop Streaming
                  </button>
                )}

                <button
                  className="button secondary"
                  onClick={copyTranscript}
                  disabled={!streamingTranscript}
                >
                  Copy Transcript
                </button>
              </div>
            </div>

            <div className="audioBox">
              <div className="recordMeta">
                <div>
                  <div className="smallText">Record timer</div>
                  <div className="timer">{formatTime(recordSeconds)}</div>
                </div>

                <div>
                  <div className="smallText">Connection</div>
                  <div className="timer" style={{ fontSize: "1rem" }}>
                    {connectionStatus}
                  </div>
                </div>
              </div>

              <div className="waveform" aria-hidden="true">
                {waveform.map((height, index) => (
                  <div
                    key={index}
                    className="bar"
                    style={{ height: `${height}px` }}
                  />
                ))}
              </div>
            </div>

            {statusMessage && <div className="status statusInfo">{statusMessage}</div>}
            {error && <div className="status statusError">{error}</div>}
          </section>

          <section className="card">
            <h2>Live Transcript</h2>

            <div className="metaGrid">
              <div className="metaItem">
                <span className="metaItemTitle">Mode</span>
                <div className="metaItemValue">Streaming PCM</div>
              </div>

              <div className="metaItem">
                <span className="metaItemTitle">Language</span>
                <div className="metaItemValue">
                  {language === "auto" ? "Auto detect" : language}
                </div>
              </div>
            </div>

            <div className="section">
              <label className="label">Committed transcript</label>
              <div className="resultBox">
                {finalText || (
                  <span className="emptyState">
                    Confirmed committed transcript will appear here.
                  </span>
                )}
              </div>
            </div>

            <div className="section">
              <label className="label">Partial transcript</label>
              <div className="resultBox">
                {partialText || (
                  <span className="emptyState">
                    Partial live transcript will appear here.
                  </span>
                )}
              </div>
            </div>

            <div className="section">
              <label className="label">Stream complete</label>
              <div className="resultBox">
                {doneText || (
                  <span className="emptyState">
                    Final stream completion text will appear here.
                  </span>
                )}
              </div>
            </div>

            <div className="section">
              <label className="label">Streaming metrics</label>
              <div className="resultBox">
                {metrics ? JSON.stringify(metrics, null, 2) : "No metrics yet."}
              </div>
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}