import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Voice to Text",
  description: "Upload or record audio and transcribe with faster-whisper",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}