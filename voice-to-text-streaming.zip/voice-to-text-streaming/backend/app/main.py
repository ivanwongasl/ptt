import json
import os
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from faster_whisper import WhisperModel

from app.streaming import StreamingSession

load_dotenv()

UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "uploads"))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

MODEL_ID = os.getenv("WHISPER_MODEL_ID", "rhasspy/faster-whisper-small-int8")
DEVICE = os.getenv("WHISPER_DEVICE", "cpu")
COMPUTE_TYPE = os.getenv("WHISPER_COMPUTE_TYPE", "int8")

ALLOWED_EXTENSIONS = {
    ".wav",
    ".mp3",
    ".m4a",
    ".mp4",
    ".webm",
    ".mpeg",
    ".mpga",
}

model: WhisperModel | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global model
    model = WhisperModel(
        MODEL_ID,
        device=DEVICE,
        compute_type=COMPUTE_TYPE,
    )
    yield


app = FastAPI(title="Voice to Text API", lifespan=lifespan)

cors_origins = [
    origin.strip()
    for origin in os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",")
    if origin.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health_check():
    return {
        "status": "ok",
        "model_id": MODEL_ID,
        "device": DEVICE,
        "compute_type": COMPUTE_TYPE,
        "model_loaded": model is not None,
    }


@app.post("/transcribe")
async def transcribe(
    file: UploadFile = File(...),
    language: Optional[str] = Form(default=None),
):
    if not file.filename:
        raise HTTPException(status_code=400, detail="Missing uploaded audio file.")

    suffix = Path(file.filename).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported audio format: {suffix}. Allowed: {sorted(ALLOWED_EXTENSIONS)}",
        )

    if model is None:
        raise HTTPException(status_code=500, detail="Model is not loaded.")

    unique_name = f"{uuid.uuid4()}{suffix}"
    input_path = UPLOAD_DIR / unique_name

    try:
        contents = await file.read()
        if not contents:
            raise HTTPException(status_code=400, detail="Uploaded file is empty.")

        input_path.write_bytes(contents)

        transcribe_kwargs = {
            "beam_size": 5,
            "vad_filter": True,
        }

        if language:
            transcribe_kwargs["language"] = language

        segments, info = model.transcribe(
            str(input_path),
            **transcribe_kwargs,
        )

        segment_list = []
        full_text_parts = []

        for segment in segments:
            cleaned = segment.text.strip()
            if cleaned:
                full_text_parts.append(cleaned)
            segment_list.append(
                {
                    "start": round(segment.start, 2),
                    "end": round(segment.end, 2),
                    "text": cleaned,
                }
            )

        full_text = " ".join(full_text_parts).strip()

        return {
            "filename": file.filename,
            "requested_language": language or "",
            "language": info.language,
            "language_probability": info.language_probability,
            "duration": info.duration,
            "text": full_text,
            "segments": segment_list,
        }

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Transcription failed: {str(exc)}")
    finally:
        try:
            if input_path.exists():
                input_path.unlink()
        except Exception:
            pass


@app.websocket("/ws/transcribe")
async def websocket_transcribe(websocket: WebSocket):
    await websocket.accept()
    print("WebSocket connected")

    session = StreamingSession()
    configured = False

    await websocket.send_text(
        json.dumps(
            {
                "type": "status",
                "message": "WebSocket connected. Send config first, then PCM audio chunks.",
            }
        )
    )

    try:
        while True:
            message = await websocket.receive()

            if "text" in message and message["text"] is not None:
                try:
                    payload = json.loads(message["text"])
                except json.JSONDecodeError:
                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "error",
                                "message": "Invalid JSON message.",
                            }
                        )
                    )
                    continue

                message_type = payload.get("type")

                if message_type == "config":
                    print("Received config:", payload)

                    session.configure(
                        language=payload.get("language"),
                        sample_rate=int(payload.get("sample_rate", 16000)),
                        channels=int(payload.get("channels", 1)),
                        encoding=payload.get("encoding", "pcm_s16le"),
                    )
                    configured = True

                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "status",
                                "message": (
                                    f"Streaming configured: "
                                    f"language={session.language or 'auto'}, "
                                    f"sample_rate={session.sample_rate}, "
                                    f"channels={session.channels}, "
                                    f"encoding={session.encoding}"
                                ),
                            }
                        )
                    )

                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "metrics",
                                "data": session.metrics(),
                            }
                        )
                    )

                elif message_type == "stop":
                    print("Received stop message")

                    result = session.stop()

                    if result["committed"]:
                        await websocket.send_text(
                            json.dumps(
                                {
                                    "type": "committed",
                                    "texts": result["committed"],
                                }
                            )
                        )

                    if result["done"]:
                        await websocket.send_text(
                            json.dumps(
                                {
                                    "type": "done",
                                    "text": result["done"],
                                }
                            )
                        )

                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "metrics",
                                "data": result["metrics"],
                            }
                        )
                    )

                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "status",
                                "message": "Streaming stopped.",
                            }
                        )
                    )

                else:
                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "error",
                                "message": f"Unsupported control message type: {message_type}",
                            }
                        )
                    )

            elif "bytes" in message and message["bytes"] is not None:
                if not configured:
                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "error",
                                "message": "Streaming session not configured yet.",
                            }
                        )
                    )
                    continue

                try:
                    chunk = message["bytes"]
                    print("Received audio bytes:", len(chunk))

                    result = session.add_audio_chunk(chunk)
                except Exception as exc:
                    print("Audio processing failed:", str(exc))
                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "error",
                                "message": f"Audio processing failed: {str(exc)}",
                            }
                        )
                    )
                    continue

                if result["partial"]:
                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "partial",
                                "text": result["partial"],
                            }
                        )
                    )

                if result["committed"]:
                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "committed",
                                "texts": result["committed"],
                            }
                        )
                    )

                if result["done"]:
                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "done",
                                "text": result["done"],
                            }
                        )
                    )

                await websocket.send_text(
                    json.dumps(
                        {
                            "type": "metrics",
                            "data": result["metrics"],
                        }
                    )
                )

            elif message.get("type") == "websocket.disconnect":
                print("WebSocket disconnect event")
                break

    except WebSocketDisconnect:
        print("WebSocket disconnected")
    except Exception as exc:
        print("Streaming server error:", str(exc))
        try:
            await websocket.send_text(
                json.dumps(
                    {
                        "type": "error",
                        "message": f"Streaming server error: {str(exc)}",
                    }
                )
            )
        except Exception:
            pass