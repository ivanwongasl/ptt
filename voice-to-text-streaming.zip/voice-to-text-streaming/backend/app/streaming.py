from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np


def pcm16le_bytes_to_float32(chunk: bytes) -> np.ndarray:
    """
    Convert raw PCM s16le mono bytes to float32 samples in [-1.0, 1.0].
    """
    if not chunk:
        return np.empty(0, dtype=np.float32)

    int_samples = np.frombuffer(chunk, dtype="<i2")
    if int_samples.size == 0:
        return np.empty(0, dtype=np.float32)

    float_samples = int_samples.astype(np.float32) / 32768.0
    return float_samples


@dataclass
class EngineUpdate:
    partial_text: str = ""
    committed_texts: list[str] = field(default_factory=list)
    done_text: str = ""
    is_done: bool = False


class BaseStreamingEngine:
    """
    Adapter contract for a future real streaming ASR engine
    such as ufal/SimulStreaming.
    """

    def __init__(
        self,
        language: Optional[str],
        sample_rate: int,
        channels: int,
    ) -> None:
        self.language = language
        self.sample_rate = sample_rate
        self.channels = channels

    def process_audio(
        self,
        new_audio: np.ndarray,
        full_audio: np.ndarray,
        seconds_received: float,
    ) -> EngineUpdate:
        raise NotImplementedError

    def finalize(self, full_audio: np.ndarray, seconds_received: float) -> EngineUpdate:
        raise NotImplementedError


class MockSimulStreamingEngine(BaseStreamingEngine):
    """
    Placeholder engine that imitates the behavior shape of a streaming system:
    - partial updates happen often
    - committed segments appear every few seconds
    - finalize emits a done_text if needed

    Replace this class later with a real SimulStreaming-backed engine.
    """

    def __init__(
        self,
        language: Optional[str],
        sample_rate: int,
        channels: int,
    ) -> None:
        super().__init__(language, sample_rate, channels)
        self.last_commit_second = 0
        self.commit_index = 0

    def process_audio(
        self,
        new_audio: np.ndarray,
        full_audio: np.ndarray,
        seconds_received: float,
    ) -> EngineUpdate:
        partial = (
            f"live partial... "
            f"sec={seconds_received:.2f}, "
            f"lang={self.language or 'auto'}, "
            f"samples={len(full_audio)}"
        )

        committed: list[str] = []

        # Mock commitment every 3 seconds
        while seconds_received >= self.last_commit_second + 3:
            self.last_commit_second += 3
            self.commit_index += 1
            committed.append(
                f"[committed segment {self.commit_index} at {self.last_commit_second:.2f}s]"
            )

        return EngineUpdate(
            partial_text="" if committed else partial,
            committed_texts=committed,
            done_text="",
            is_done=False,
        )

    def finalize(self, full_audio: np.ndarray, seconds_received: float) -> EngineUpdate:
        if seconds_received <= 0:
            return EngineUpdate(
                partial_text="",
                committed_texts=[],
                done_text="[no audio received]",
                is_done=True,
            )

        return EngineUpdate(
            partial_text="",
            committed_texts=[],
            done_text=f"[stream complete after {seconds_received:.2f}s]",
            is_done=True,
        )


@dataclass
class StreamingSession:
    language: Optional[str] = None
    sample_rate: int = 16000
    channels: int = 1
    encoding: str = "pcm_s16le"

    chunk_count: int = 0
    bytes_received: int = 0
    samples_received: int = 0

    partial_text: str = ""
    committed_texts: list[str] = field(default_factory=list)
    done_text: str = ""

    audio_buffer: np.ndarray = field(
        default_factory=lambda: np.empty(0, dtype=np.float32)
    )

    engine: Optional[BaseStreamingEngine] = None

    def configure(
        self,
        language: Optional[str],
        sample_rate: int = 16000,
        channels: int = 1,
        encoding: str = "pcm_s16le",
    ) -> None:
        if language == "auto":
            language = None

        self.language = language
        self.sample_rate = sample_rate
        self.channels = channels
        self.encoding = encoding

        self.engine = MockSimulStreamingEngine(
            language=self.language,
            sample_rate=self.sample_rate,
            channels=self.channels,
        )

    @property
    def seconds_received(self) -> float:
        if self.sample_rate <= 0:
            return 0.0
        return self.samples_received / float(self.sample_rate)

    def add_audio_chunk(self, chunk: bytes) -> dict:
        if self.encoding != "pcm_s16le":
            raise ValueError(f"Unsupported encoding: {self.encoding}")

        if self.channels != 1:
            raise ValueError("Only mono audio is supported in this scaffold.")

        if self.engine is None:
            raise ValueError("Streaming engine is not configured.")

        self.chunk_count += 1
        self.bytes_received += len(chunk)

        float_audio = pcm16le_bytes_to_float32(chunk)
        self.samples_received += len(float_audio)

        if float_audio.size > 0:
            self.audio_buffer = np.concatenate([self.audio_buffer, float_audio])

        update = self.engine.process_audio(
            new_audio=float_audio,
            full_audio=self.audio_buffer,
            seconds_received=self.seconds_received,
        )

        committed_now = []
        if update.committed_texts:
            self.committed_texts.extend(update.committed_texts)
            committed_now = update.committed_texts

        self.partial_text = update.partial_text
        if update.done_text:
            self.done_text = update.done_text

        return {
            "partial": self.partial_text,
            "committed": committed_now,
            "done": self.done_text,
            "metrics": self.metrics(),
        }

    def stop(self) -> dict:
        if self.engine is None:
            raise ValueError("Streaming engine is not configured.")

        update = self.engine.finalize(
            full_audio=self.audio_buffer,
            seconds_received=self.seconds_received,
        )

        committed_now = []
        if update.committed_texts:
            self.committed_texts.extend(update.committed_texts)
            committed_now = update.committed_texts

        self.partial_text = update.partial_text
        self.done_text = update.done_text

        return {
            "partial": self.partial_text,
            "committed": committed_now,
            "done": self.done_text,
            "metrics": self.metrics(),
        }

    def metrics(self) -> dict:
        return {
            "chunk_count": self.chunk_count,
            "bytes_received": self.bytes_received,
            "samples_received": self.samples_received,
            "seconds_received": round(self.seconds_received, 3),
            "sample_rate": self.sample_rate,
            "channels": self.channels,
            "encoding": self.encoding,
            "language": self.language or "auto",
            "committed_count": len(self.committed_texts),
            "buffer_samples": int(self.audio_buffer.size),
        }