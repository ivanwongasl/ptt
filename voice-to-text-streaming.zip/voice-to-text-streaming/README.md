# Voice to Text

A Next.js + FastAPI project with two transcription modes:

1. **Batch transcription**
   - Upload a file or record audio
   - Send the full audio to FastAPI
   - Transcribe with `faster-whisper`

2. **Streaming transcription (Version 3 scaffold)**
   - Open a live streaming page
   - Capture microphone audio in the browser
   - Send raw PCM audio over WebSocket
   - Receive partial, committed, done, and metrics messages
   - Backend structure is prepared for future `ufal/SimulStreaming` integration

> Important: the current Version 3 streaming backend is a **SimulStreaming-ready adapter scaffold**, not the real SimulStreaming engine yet.

---

# Project structure

```text
voice-to-text/
├─ frontend/
│  ├─ app/
│  │  ├─ globals.css
│  │  ├─ layout.tsx
│  │  ├─ page.tsx
│  │  └─ streaming/
│  │     └─ page.tsx
│  ├─ package.json
│  ├─ tsconfig.json
│  ├─ next.config.js
│  └─ .env.local
├─ backend/
│  ├─ app/
│  │  ├─ main.py
│  │  └─ streaming.py
│  ├─ requirements.txt
│  └─ .env
└─ README.md
```

---

# Features

## Batch mode
- Upload audio file
- Record audio in browser
- Choose transcription language
- Get full transcript
- Copy transcript

## Streaming mode
- Live microphone capture
- Raw PCM 16-bit mono streaming over WebSocket
- Partial live transcript
- Committed transcript segments
- Done/final stream text
- Streaming metrics
- Timer + waveform UI
- Prepared for real `ufal/SimulStreaming` integration later

---

# Requirements

## System
- Node.js 18+ or 20+
- Python 3.10+ or 3.11 recommended
- pip
- microphone permission in your browser

## Recommended
- Python virtual environment

---

# Backend setup

## 1. Go to backend

```bash
cd backend
```

## 2. Create virtual environment

### macOS / Linux
```bash
python -m venv .venv
source .venv/bin/activate
```

### Windows PowerShell
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

## 3. Install dependencies

```bash
pip install -r requirements.txt
```

Expected important packages:
- `fastapi`
- `uvicorn`
- `python-multipart`
- `python-dotenv`
- `faster-whisper`
- `requests`
- `numpy`

## 4. Create backend environment file

Create `backend/.env`:

```bash
UPLOAD_DIR=uploads
CORS_ORIGINS=http://localhost:3000
WHISPER_MODEL_ID=rhasspy/faster-whisper-small-int8
WHISPER_DEVICE=cpu
WHISPER_COMPUTE_TYPE=int8
```

## 5. Run backend

```bash
uvicorn app.main:app --reload --port 8000
```

Backend will run at:

- `http://localhost:8000`

## 6. Test backend health

Open in browser or use curl:

```bash
curl http://localhost:8000/health
```

Expected response looks like:

```json
{
  "status": "ok",
  "model_id": "rhasspy/faster-whisper-small-int8",
  "device": "cpu",
  "compute_type": "int8",
  "model_loaded": true
}
```

> On first run, `faster-whisper` may download the model, so startup can take longer.

---

# Frontend setup

## 1. Go to frontend

```bash
cd frontend
```

## 2. Install dependencies

```bash
npm install
```

## 3. Create frontend environment file

Create `frontend/.env.local`:

```bash
NEXT_PUBLIC_API_BASE_URL=http://localhost:8000
```

## 4. Run frontend

```bash
npm run dev
```

Frontend will run at:

- `http://localhost:3000`

---

# Pages

## Batch transcription page
Open:

- `http://localhost:3000`

This page supports:
- audio upload
- browser recording
- one-shot transcription

## Streaming transcription page
Open:

- `http://localhost:3000/streaming`

This page supports:
- live mic streaming
- partial transcript display
- committed transcript display
- stream completion display
- metrics panel

---

# How Version 3 streaming works

## Frontend
The streaming page:
- uses `getUserMedia` to capture microphone input
- uses the Web Audio API
- downsamples audio to **16kHz**
- converts float audio into **PCM s16le**
- sends binary PCM frames through WebSocket

## Backend
The backend:
- accepts a WebSocket connection at `/ws/transcribe`
- receives a JSON `config` message first
- receives PCM binary chunks
- decodes PCM bytes into `numpy` float32 arrays
- appends them to a rolling audio buffer
- passes them into a streaming engine adapter

Current engine:
- `MockSimulStreamingEngine`

Current behavior:
- emits simulated:
  - `partial`
  - `committed`
  - `done`
  - `metrics`

This is intentionally structured so you can later replace the mock engine with a real `ufal/SimulStreaming` engine.

---

# Streaming WebSocket protocol

## Client -> server

### 1. Config message
Sent first:

```json
{
  "type": "config",
  "language": "en",
  "sample_rate": 16000,
  "encoding": "pcm_s16le",
  "channels": 1
}
```

`language` can also be:

```json
"auto"
```

### 2. Binary audio chunks
After config, client sends:
- raw PCM bytes
- format: signed 16-bit little-endian
- mono
- 16kHz

### 3. Stop message
When user stops streaming:

```json
{
  "type": "stop"
}
```

---

## Server -> client

### Status
```json
{
  "type": "status",
  "message": "Streaming configured..."
}
```

### Partial
```json
{
  "type": "partial",
  "text": "live partial..."
}
```

### Committed
```json
{
  "type": "committed",
  "texts": ["segment 1", "segment 2"]
}
```

### Done
```json
{
  "type": "done",
  "text": "final stream summary"
}
```

### Metrics
```json
{
  "type": "metrics",
  "data": {
    "chunk_count": 10,
    "bytes_received": 32000,
    "samples_received": 16000,
    "seconds_received": 1.0,
    "sample_rate": 16000,
    "channels": 1,
    "encoding": "pcm_s16le",
    "language": "en",
    "committed_count": 1,
    "buffer_samples": 16000
  }
}
```

### Error
```json
{
  "type": "error",
  "message": "Audio processing failed..."
}
```

---

# Files used in Version 3

## Backend
- `backend/app/main.py`
- `backend/app/streaming.py`
- `backend/requirements.txt`

## Frontend
- `frontend/app/streaming/page.tsx`

---

# Running both services together

Open two terminals.

## Terminal 1: backend
```bash
cd backend
source .venv/bin/activate
uvicorn app.main:app --reload --port 8000
```

## Terminal 2: frontend
```bash
cd frontend
npm run dev
```

Then open:
- batch page: `http://localhost:3000`
- streaming page: `http://localhost:3000/streaming`

---

# Troubleshooting

## 1. Microphone permission denied
Make sure your browser allows microphone access for `localhost`.

## 2. WebSocket connection failed
Check:
- backend is running on port `8000`
- frontend `.env.local` points to `http://localhost:8000`
- browser console for WebSocket errors

## 3. Backend CORS issues
Check `backend/.env`:

```bash
CORS_ORIGINS=http://localhost:3000
```

Then restart backend.

## 4. Model download takes time
On first startup, the whisper model may download automatically.

## 5. `ModuleNotFoundError`
Make sure dependencies are installed:

```bash
pip install -r requirements.txt
```

## 6. Streaming page shows mock transcript behavior
This is expected in Version 3.

The current engine is:

- `MockSimulStreamingEngine`

It is a scaffold for future replacement.

---

# How to move from Version 3 to real SimulStreaming

Current architecture already separates:

1. **Transport layer**
   - WebSocket
   - raw PCM chunks

2. **Session layer**
   - `StreamingSession`

3. **Engine layer**
   - `BaseStreamingEngine`

That means to integrate real SimulStreaming later, you mainly replace:

```python
MockSimulStreamingEngine
```

with a real engine implementation, for example:

```python
RealSimulStreamingEngine
```

The future real engine will likely:
- initialize SimulStreaming model/session state
- consume incremental PCM audio
- return:
  - unstable partial text
  - newly committed text
  - final completion text

---

# Recommended next step

If you want to continue toward real integration, the next best step is:

- create a `RealSimulStreamingEngine` skeleton
- wire imports and expected method calls
- map SimulStreaming outputs into:
  - `partial`
  - `committed`
  - `done`

---

# Example local workflow

## Start backend
```bash
cd backend
source .venv/bin/activate
uvicorn app.main:app --reload --port 8000
```

## Start frontend
```bash
cd frontend
npm install
npm run dev
```

## Open page
```text
http://localhost:3000/streaming
```

## Use it
1. choose a language
2. click **Start Streaming**
3. allow microphone access
4. speak into microphone
5. watch:
   - partial transcript
   - committed transcript
   - metrics
6. click **Stop Streaming**

---

# Notes

- Batch transcription is real and uses `faster-whisper`
- Streaming Version 3 currently uses a mock engine adapter
- Raw PCM transport is already a strong foundation for future real streaming ASR integration
- This design is much better for SimulStreaming than sending `webm` recorder chunks

---

# License / dependency notes

If you later integrate `ufal/SimulStreaming`, review:
- its README
- model/runtime requirements
- license
- Python dependencies
- expected audio format and session API